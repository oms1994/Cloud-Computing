The project Contains 2  programs:
1. KNN classifier 
2. Naive Bayes Classifier


1. KNN classifier 

1.User Input the Train data file else presses 1 and the program selects same train data  as shared by professor(Project1_train_data.txt)
2.The Program takes any value for K from user , default value is 3
3.Also user inputs the test data set shared by professor (Text_Data_for_Project1_test_data.txt)
4.The program taking all the inputs classifies all the dataponts and predicts the class label for new test data instance
using KNN 

Steps :
1.Unzip folder 
2.In CMD run KNN.py
3.Press 1 to choose  Project1_train_data.txt
4. Enter k value
5. Enter test data file path :Text_Data_for_Project1_test_data.txt
6. Program Predicts classs file.


2.Naive Bayes Classifier :




1.For Naive Bayes Classifier , the program takes the train data and calculates the probablities  based on Bayes theorem.
2. The test data is classified using the Naive Bayes Classifier

Steps:
1.Unzip folder 
2.In CMD run naive_bayes.py