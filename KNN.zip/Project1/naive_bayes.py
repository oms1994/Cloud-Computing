from sklearn import preprocessing
from sklearn.naive_bayes import GaussianNB


def test_data_input():

    training_data_input = []
    file= open("Project1_train_data.txt","r")
    rawdata = file.read()
    data=rawdata.splitlines()
    file.close()
    data_labels = data[0].split()
    main_tuple_list = []
    class_label = []
    

    for i in range(1,len(data)):
       
        columns = data[i].split()
        train_data = {}

        for j in range(len(columns)):
          
            train_data[data_labels[j]] = columns[j]

        training_data_input.append(train_data)


  
    for j in range(len(data_labels)):
        label_hotcoded = []
        label = data_labels[j]


        for i in range(len(training_data_input)-1):

            val = training_data_input[i][label]
            label_hotcoded.append(val)
         
        labelsencoded = preprocessing.LabelEncoder()
        attribute_encoded = labelsencoded.fit_transform(label_hotcoded)
        temp=(zip(attribute_encoded, label_hotcoded))
        final_class = dict(temp)


        if(j <= len(data_labels)-2):
            main_tuple_list.append(list(attribute_encoded))
        else:
            class_label.append(list(attribute_encoded))
  
   

    N_tuple_list = [zip([(l) for l in main_tuple_list])]

    templist=(map(tuple, zip(*main_tuple_list)))
    N_tuple_list = list(templist)



    naive_model = GaussianNB()
    naive_model.fit(N_tuple_list, class_label[0])

    class_predicted = naive_model.predict([[0, 0, 3, 0, 1, 1]]) 
    print("class_predicted:", class_predicted[0])
    print("class:", final_class[class_predicted[0]])







if __name__ == "__main__":
    test_data_input()