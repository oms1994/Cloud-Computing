#File Reader Module 
import sys
import re
from operator import itemgetter

def Diff(li1, li2): 
    return (list(set(li1) - set(li2))) 

print ("Enter File path for new Training Data Set  OR Press 1 to use Project1_train_data.txt");
print("Example: F\Data Minning\Project1_train_data.txt");
path=input("Enter path")
if(path == "1"):
	path="Project1_train_data.txt";
kval=int(input("Enter value of K from ,default val 3"))
#print (kval)
if(kval>0 & kval<=8):
	k=kval;
else :
	k=3;	
print(k)
# open and Parse the file

print("Training file used :"+path);
fptr=open(path,"r");
Labels=[];
filtlabellist=[];
Hdist=[];
Hlabel=[];
#print (fptr.readline());
i=1;


with open(path) as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
for x in content:
	
	Labels.append(x.strip().split(" "));
for e in Labels:
	filtlabellist.append(list(filter(None,e)));

filtlabellist.pop(0)
filtlabellist.pop(len(filtlabellist)-1)
tvar=[];
fe=[];
print("KNN Classifier Training Completed");
print("Enter Test Data file")
path=input("Enter path")
tlist=[];
flist=[];
KNN_ele=[];

with open(path) as f:
    content = f.readlines()
   # print(content)
# you may also want to remove whitespace characters like `\n` at the end of each line
for x in content:		
	tlist.append(x.strip().split(" "));

for e in tlist:
	flist.append(list(filter(None,e)));

flist.pop(0) 
flist[0].append("class")
print("test data")
print(flist)
print("Filtered Data")
#flist[0].append("class");

hd=0;
print(filtlabellist)
print("Filtered Data")
i=0;

for y in  filtlabellist:
	for e in y:
		#print (str(e)+str(flist[0][i]));
		if(flist[0][i]!=str(e)):
			hd+=1;
		i+=1;
		if(i==len(flist[0])):
			i=0;
	Hdist.append(str(hd))
	Hlabel.append(str(e))		
	KNN_ele.append(str(hd)+"-"+str(e));
	hd=0;
print(Hdist)
print(Hlabel)
sortedlist=[x for _,x in sorted(zip(Hdist,Hlabel))]
max=sortedlist[:k].count(sortedlist[0])
classname=sortedlist[0]
for i in range(k):
	if max<sortedlist[:k].count(sortedlist[i]):
		max=sortedlist[:k].count(sortedlist[i])
		classname=sortedlist[i]		


print (str(flist[0][0])+"  is  a  "+ classname);
#KNN_ele.sort();

#	print(KNN_ele)
#print (str(flist[0][0])+"  is  a  "+ str(KNN_ele[0].split("-")[1]));