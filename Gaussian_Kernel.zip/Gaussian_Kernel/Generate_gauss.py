from copy import deepcopy
import random as random
import matplotlib.pyplot as plot
import numpy as np


#Global Declarations
np.random.seed(200)
global getfig
getfig = plot.figure(constrained_layout=False)
gs = getfig.add_gridspec(3, 3)# 2 rows , 3 cols


#Creating Clusters , Using Gaussian Distace
def init_data_clusters():	
	ax = getfig.add_subplot(gs[0, 0])
	data_values={}
	k=3 #No of data_clusters
	centre_pts = np.asarray([[5,5], [-5,5], [-5,-5]]) #Cluster Centres
	NoDatapts=100
	dimension=2
	sigma=2#other vals

	covar_matrix = [[sigma**2, 0], [0, sigma**2]]
	x = np.zeros((1,))
	y = np.zeros((1,))
	for i in range(0, centre_pts.shape[0]):
		centre = centre_pts[i]
		#Generating Gaussian Distance
		data_values[i] = np.random.multivariate_normal(mean=centre,cov=covar_matrix,size=NoDatapts).T	
		x = np.hstack((x, data_values[i][0]))
		y = np.hstack((y, data_values[i][1]))
	x = x[1:]
	y = y[1:]
	data = np.vstack((x,y)).T
	clustCX = np.random.randint(np.min(x), np.max(x), size=k)
	clustCY = np.random.randint(np.min(y), np.max(y), size=k)
	return(ax,data,x,y,clustCX,clustCY)
	
def getcolor(i):
	rgbl=["yellow","navy","aqua","g"]
	return rgbl[i]


def draw_data_pts(obj,xcord,ycord,mlabel,mcolor,dlabel):
	obj.set_title(label=dlabel,y=-0.30)
	obj.scatter(xcord, ycord, marker=mlabel, color=mcolor, edgecolors='brown')	
	
		

def draw_centres(obj,Centr_X,Centr_Y,title):
	obj.set_title(label=title,y=-0.30)
	obj.scatter(Centr_X, Centr_Y, marker='8', color='r', s=150, edgecolors='brown')
	


def kmenas(data,k,clustCX,clustCY,total_iterations):

    C = np.array(list(zip(clustCX, clustCY)), dtype=np.float32)
    data_clusters = np.zeros(data.shape[0])    
    for iteration in range(total_iterations):
        for i, instance in enumerate(data):
            distances = np.linalg.norm(instance - C, axis=1)#calculate Eucledien distace 
            cluster = np.argmin(distances)
            data_clusters[i] = cluster
        centroidval_old = deepcopy(C)
        data_pts = {}
        bx = getfig.add_subplot(2, 3, iteration+2)
        for i in range(k):
            data_pts[i] = np.vstack([data[j] for j in range(data.shape[0]) if data_clusters[j] == i])
            C[i] = np.mean(data_pts[i], axis=0)
            draw_data_pts(bx,data_pts[i][:, 0],data_pts[i][:, 1],'p',getcolor(i),None)
       	draw_centres(bx,centroidval_old[:, 0],centroidval_old[:, 1],str(iteration+1)+" iteration")
       

ax,data,x,y,clustCX,clustCY=init_data_clusters()
draw_data_pts(ax,x,y,'o','green',None)
draw_centres(ax,clustCX,clustCY,"Data Points with Centroids")
kmenas(data,3,clustCX,clustCY,3)

plot.show(getfig)
