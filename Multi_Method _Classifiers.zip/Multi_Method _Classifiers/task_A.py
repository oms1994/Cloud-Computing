"""
Name:Omkar Sahasrabudhe
Name: Prem Patel
ID :1001668155
Id : 1001661919
"""


from sklearn import metrics
from sklearn import svm
import numpy as np
import pandas as pd
import operator
import math
import matplotlib.pyplot as plotter

# Subroutine 1: Method for Slicing given data in to classise vectors
def pickDataClass(fileip_Name, class_ids):
    data = pd.read_csv(fileip_Name, header=None).values
    total_samples=39
    selected_data = createtranspose(data[1:,:])
    Class_labels = data.shape[0] - 1   
    y_train, y_test = [], []
    class_vectors= np.zeros((1, Class_labels))
    for cid in class_ids:
        i = cid - 1
        class_vectors = np.vstack((class_vectors, selected_data[(i)]))
    class_vectors = class_vectors[1:, :]    
    return(class_vectors,total_samples,class_ids)

# Subroutine 2: Method for Spliting data in Test and Train data  
def splitData2TestTrain(fileip_Name, class_ids, samples, trainingInst, testingInst):
    data = pd.read_csv(fileip_Name, header=None).values
    vectorcntx = data.shape[0] - 1
    x_data = createtranspose(data[1:, :])
    y_data = createtranspose(data[0, :])
    
    x_train = np.zeros((1, vectorcntx))
    x_test  = np.zeros((1, vectorcntx))
    y_train, y_test = [], []
    #print(f"class_ids = {class_ids}")

    for cid in class_ids:
        i = cid - 1
        sample_count=samples * i
        total_count =sample_count + trainingInst
    #Collecting x,y for Train Matrix data    
        x_train = np.vstack(
            (x_train, x_data[sample_count:(total_count), :]))
        y_train = np.hstack(
            (y_train, y_data[sample_count:(total_count)]))
    #Collecting x,y for Test Matrix data     
        x_test = np.vstack((x_test, x_data[(total_count + 1):(
            total_count + testingInst), :]))
        y_test = np.hstack((y_test, y_data[(
            total_count + 1):(total_count + testingInst)]))

    return x_train[1:, :], y_train, x_test[1:, :], y_test


def storeData(xTrain, yTrain, xTest, yTest):
    rows = yTrain.shape[0]
    xTrain = createtranspose(xTrain)
    row_x, col_x = xTrain.shape
    file = open("trainingData.txt", "w")
    #train data
    #write class labels and train data to trainingData.txt
    writetofile(file,rows,xTrain,yTrain,row_x,col_x)
    # test data
    #write class labels and test data to testingData.txt
    n = yTest.shape[0]
    xTest = createtranspose(xTest)
    row_x, col_x = xTest.shape
    file = open("testingData.txt", "w")
    writetofile(file,n,xTest,yTest,row_x,col_x)
   


#returns a transpose of the passed data object
def createtranspose(dataobject):
    return(np.transpose(dataobject))

#converts a passed letter stream to Integer values
def letter_2_digit_convertlist(word):
     name_number = {'a':1, 'b':2, 'c':3, 'd':4,'e':5, 'f':6, 'g':7, 'h':8,'i':9, 'j':10, 'k':11, 'l':12,'m':13, 'n':14, 'o':15, 'p':16,'q':17, 'r':18, 's':19, 't':20,'u':21, 'v':22, 'w':23,'x':24,'y':25, 'z':26}
     classid=[];
     #print(word)            

     for i in word:     
        classid.append(name_number[i])
     #print(classid)
     return classid



# Creating training and testing data for centroid classifier

def storeCentroidData(x_train, y_train, x_test, y_test, trainingLen):
    # training data
    file = open("CentroidTrainingdata.txt", "w")
    x_train = createtranspose(x_train)
    row_x, col_x = x_train.shape
    
    for i in range(1, 41):
        file.write(str(int(i)))
        if (i < 40):
            file.write(',')
    file.write("\n")
    for i in range(0, row_x):
        for j in range(0, 40):
            classXCen = round(
                (float(np.sum(x_train[i][j*trainingLen:(j+1)*trainingLen])/trainingLen)), 2)
            file.write(str(classXCen))
            if (j < 39):
                file.write(',')
        file.write('\n')
    file.close()

    # testing data
    file = open("CentroidTestingdata.txt", "w")
    x_test = createtranspose(x_test)
    rows = y_test.shape[0]
    row_x, col_x = x_test.shape

    for i in range(0, rows):
        file.write(str(int(y_test[i])))
        if (i < rows - 1):
            file.write(',')
    file.write("\n")
    for i in range(0, row_x):
        for j in range(0, col_x):
            file.write(str(int(x_test[i][j])))
            if (j < col_x - 1):
                file.write(',')
        file.write("\n")
    file.close()

# Calculating the Euclidean distance for KNN and Centroid classifier
def get_Edistance(x1, x2, length):
    e_distannce = 0
    for x in range(length):
        e_distannce += pow((x1[x] - x2[x]), 2)  # (x1 - x2)^2
    return math.sqrt(e_distannce)

# Finding the k nearest neighbors

def get_Kneighbors(trainingSet, testingInst, k):
    distances = []
    length = len(testingInst)-1
    for x in range(len(trainingSet)):
        dist = get_Edistance(testingInst, trainingSet[x], length)
        distances.append((trainingSet[x], dist))
    # to sort the distances from shortest to longest
    distances.sort(key=operator.itemgetter(1))
    neighbors = []
    for x in range(k):
        neighbors.append(distances[x][0])
    return neighbors

# Finding the Nearest Neighbors
def get_Knneighbors(neighbors):

    classVotes = {}
    for x in range(len(neighbors)):
        response = neighbors[x][0]

        if response in classVotes:
            classVotes[response] += 1
        else:
            classVotes[response] = 1
    sortedVotes = sorted(classVotes.items(),
                         key=operator.itemgetter(1), reverse=True)

    return sortedVotes[0][0]

# Evaluating the accuracy of the classifier
def get_Accuracyval(testdataSet, predictions):
    count_correct = 0
    for x in range(len(testdataSet)):
        if testdataSet[x][0] == predictions[x]:
            count_correct += 1
    accuracy=count_correct/float(len(testdataSet))
    percentaccuracy=accuracy*100.0        
    return percentaccuracy


# Writes passed data to file in rows and Colum format
def writetofile(file,rows,xT,yT,row_x,col_x):
    for i in range(0, rows):
        file.write(str(int(yT[i])))
        if (i < rows - 1):
            file.write(',')
    file.write("\n")   
    for i in range(0, row_x):
        for j in range(0, col_x):
            file.write(str(int(xT[i][j])))
            if (j < col_x - 1):
                file.write(',')
        file.write("\n")
    file.close()



def classify_data(option):

    if (option == "KNN"):
        file1 = pd.read_csv("trainingData.txt", header=None)
        trainingData = file1.values
        trainingData = trainingData.transpose()

        file2 = pd.read_csv("testingData.txt", header=None)
        testingData = file2.values
        testingData = testingData.transpose()

        predictions = []
        k = 5
        for x in range(len(testingData)):
            neighbors = get_Kneighbors(trainingData, testingData[x], k)
            nearestClass = get_Knneighbors(neighbors)
            predictions.append(nearestClass)
#       for x in range(len(testingData)):
            #print("*********")
            #print("Actual data") 
            #print(testingData[x][0]) 
            #print("predictions")
            #print(predictions[x])
            #print("*********")
        accuracy = get_Accuracyval(testingData, predictions)
        print("Accuracy using KNN: {:05.2f}%".format(accuracy))
    elif (option == "SVM"):
        svmclassifier = svm.LinearSVC()
        svmclassifier.fit(xTrain, yTrain)
        # calculating prediction accuracy
        predicted = svmclassifier.predict(xTest)
        actual = yTest
        accuracy = metrics.accuracy_score(actual, predicted) * 100
        print("Accuracy using SVM: {:05.2f}%".format(accuracy))

    elif(option == "LRG"):
        rx_train, cx_train = x_train.transpose().shape
        rx_test, cx_test = x_test.transpose().shape

        Atrain = np.ones((1, cx_train))
        Atest = np.ones((1, cx_test))
        Xtrain_padding = np.row_stack((x_train.transpose(), Atrain))
        # computing the regression coefficients
        Xtest_padding = np.row_stack((x_test.transpose(), Atest))

        B_padding = np.dot(np.linalg.pinv(Xtrain_padding.T), y_train.T)

        ytest_padding = np.dot(B_padding.T, Xtest_padding)
        ytest_padding_argmax = np.argmax(ytest_padding, axis=0)+1
        err_test_padding = y_test - ytest_padding_argmax

        accuracy = (float((np.nonzero(err_test_padding)[
                    0].size-1)/len(err_test_padding)))*100
        print("Accuracy using Lin Reg.: {:05.2f}%".format(accuracy))

    elif(option == "Centroid"):
        storeCentroidData(xTrain, yTrain, xTest, yTest, trainingInst)

        file1 = pd.read_csv("CentroidTrainingdata.txt", header=None)
        trainingData = file1.values
        trainingData = trainingData.transpose()

        file2 = pd.read_csv("CentroidTestingdata.txt", header=None)
        testingData = file2.values
        testingData = testingData.transpose()

        predictions = []
        k = 1

        for x in range(len(testingData)):
            neighbors = get_Kneighbors(trainingData, testingData[x], k)
            nearestClass = get_Knneighbors(neighbors)
            predictions.append(nearestClass)
        accuracy = get_Accuracyval(testingData, predictions)
        print("Accuracy using Centroid: {:05.2f}%".format(accuracy)) 

    return accuracy

fileip_Name = 'HandWrittenLetters.txt'
#samples = 39
option = input(("Press 1 to take the class_ids = [A,B,C,D,E] \nelse Enter your class class_ids"))

if(option==str(1)):
    class_ids = [1, 2, 4, 5, 7, 11, 13, 20]
else:
    class_ids = letter_2_digit_convertlist(option)


class_vectors,total_samples,class_ids=pickDataClass(fileip_Name,class_ids)
testingInst = 9
trainingInst = total_samples-testingInst  # first 30 images for training
x_train, y_train, x_test, y_test = splitData2TestTrain(fileip_Name, class_ids, total_samples, trainingInst, testingInst)
xTrain = x_train
yTrain = y_train
xTest = x_test
yTest = y_test
storeData(x_train, y_train, x_test, y_test)

y_knn = classify_data("KNN")
y_svm = classify_data("SVM")
y_centroid = classify_data("Centroid")
y_lr = classify_data("LRG")


#plotter
classifiers = np.array(['KNN','SVM', 'Lin Reg.','Centroid'])
y_pos = np.arange(len(classifiers))
performance = np.array([y_knn,y_svm, y_lr, y_centroid])
plotter.rcdefaults()
plotter.barh(y_pos, performance, align='center', color='green')
plotter.yticks(y_pos, classifiers)
plotter.xlabel('Prediction-Accuracy')
plotter.title('Classifier Performance:Hand Written Letters Dataset')
plotter.savefig('ClassifierPerformance.png', bbox_inches='tight')
plotter.show()
