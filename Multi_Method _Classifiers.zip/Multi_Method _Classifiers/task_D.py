"""
Name:Omkar Sahasrabudhe
Name: Prem Patel
ID :1001668155
Id : 1001661919
"""

from sklearn.neighbors.nearest_centroid import NearestCentroid
import matplotlib.pyplot as plt
from sklearn import metrics
import pandas as pd
import numpy as np

img_samples = 39

def write_data (xTrain, yTrain, xTest, yTest):
  file = open("trainingData.txt", "w")
  rows = yTrain.shape[0]
  for i in range(0, rows):
      file.write(str(int(yTrain[i])))
      if (i < rows - 1):
          file.write(',')
  file.write("\n")
  xTrain = np.transpose(xTrain)
  row_x, col_x = xTrain.shape
  for i in range(0, row_x):
      for j in range(0, col_x):
          file.write(str(int(xTrain[i][j])))
          if (j < col_x - 1):
              file.write(',')
      file.write("\n")
  file.close()
  # test_split data
  file = open("testingData.txt", "w")
  n = yTest.shape[0]
  for i in range(0, n):
      file.write(str(int(yTest[i])))
      if (i < n - 1):
          file.write(',')
  file.write("\n")
  xTest = np.transpose(xTest)
  row_x, col_x = xTest.shape
  for i in range(0, row_x):
      for j in range(0, col_x):
          file.write(str(int(xTest[i][j])))
          if (j < col_x - 1):
              file.write(',')
      file.write("\n")
  file.close()


def extract_data(inp_file, selected_class, training_instances, test_instances):
  data = pd.read_csv(inp_file, header=None).to_numpy()

  print(f"data.shape = {data.shape}")
  
  firstnum, secondnum = data.shape

  print(f"firstnum, secondnum = {firstnum, secondnum}")
  
  data_X = np.transpose(data[1:, :])
  data_Y = np.transpose(data[0, :])

  print(f"data_X = {data_X}")
  print(f"data_Y = {data_Y}")
  
  train_B, test_B = [], []

  train_A = np.zeros((1, firstnum - 1))
  
  test_A = np.zeros((1, firstnum - 1))
  
  for i in selected_class:
      j = i - 1
      train_A = np.vstack((train_A, data_X[(img_samples * (j)):(img_samples * j) + training_instances, :]))
      train_B = np.hstack((train_B, data_Y[(img_samples * (j)):(img_samples * j) + training_instances]))
      
      test_A = np.vstack((test_A, data_X[(img_samples * j) + training_instances:(img_samples * j) + img_samples, :]))
      test_B = np.hstack((test_B, data_Y[(img_samples * j) + training_instances:(img_samples * j) + img_samples]))
  
  train_A = train_A[1:, :]
  test_A = test_A[1:, :]
  return train_A, train_B, test_A, test_B


def plot_graph(acc):
  x = [1, 2, 3, 4, 5, 6, 7]
  plt.scatter(x, acc, color='green', marker='o')
  plt.plot(x, acc, label='Centroid')

  plt.legend(loc='lower right', frameon=False)
  plt.title('Centroid Classifier: Performance Measure')

  plt.show()
  

def main():
  acc_sum = 0

  acc = []

  inp_file = 'HandWrittenLetters.txt';

  selected_class = [4,8,12,15,16,18,20,22,23,26]

  train_split = [5, 10, 15, 20, 15, 30, 35] #given train_split splits
  test_split =  [34, 29, 24, 19, 24, 9, 4] #given test_split splits

  for i in range(0,7):
      if (train_split[i] + test_split[i] == img_samples):
          train_A, train_B, test_A, test_B = extract_data(inp_file, selected_class, train_split[i], test_split[i])
          
          write_data(train_A, train_B, test_A, test_B)
          
          train_file = pd.read_csv('trainingData.txt', header=None)
          trainData = train_file.to_numpy()
          
          test_file = pd.read_csv('testingData.txt', header=None)
          testData = test_file.to_numpy()

          cntrd = NearestCentroid()
          cntrd.fit(np.transpose(trainData[1:, :]), np.transpose(trainData[0, :]))

          prdctn = cntrd.predict(np.transpose(testData[1:, :]))

          acc.append(metrics.accuracy_score(np.transpose(testData[0, :]), prdctn) * 100)
          print("Accuracy for Centroid: {:05.2f}%".format(acc[i]))
          
          acc_sum = acc_sum + acc[i]
      else:
          print("The total number of samples is not equal to the number of images")

  avg_acc = acc_sum / 7

  print("Average Accuracy:", avg_acc)

  plot_graph(acc)


if __name__ == '__main__':
    main()