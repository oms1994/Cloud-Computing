"""
Name:Omkar Sahasrabudhe
Name: Prem Patel
ID :1001668155
Id : 1001661919
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plotter
import math
import operator
from sklearn import svm
from sklearn import metrics
from sklearn.model_selection import KFold

#Reading pixel data
faceData = pd.read_csv('ATNTFaceImages400.txt', delimiter = ',', header = None).values
def createtranspose(dataobject):
    return(np.transpose(dataobject))

dataX = createtranspose(faceData[1:, :])
dataY = createtranspose(faceData[0, :])



def writetofile(file,rows,xT,yT,row_x,col_x):
    for i in range(0, rows):
        file.write(str(int(yT[i])))
        if (i < rows - 1):
            file.write(',')
    file.write("\n")   
    for i in range(0, row_x):
        for j in range(0, col_x):
            file.write(str(int(xT[i][j])))
            if (j < col_x - 1):
                file.write(',')
        file.write("\n")
    file.close()


def pickDataClass(fileName, class_ids, samples, trainingInst, testingInst):
  data = pd.read_csv(fileName, header = None).values
  x_data = createtranspose(data[1:, :])
  y_data = createtranspose(data[0, :])
  
  vectorcntx = data.shape[0] - 1
  
  y_train, y_test = [], []
  x_train = np.zeros((1, vectorcntx))
  x_test = np.zeros((1, vectorcntx))
  
  for k in class_ids:
    i = k - 1
    sample_count=samples * i
    total_count =sample_count + trainingInst
    x_train = np.vstack((x_train, x_data[sample_count:(total_count), :]))
    y_train = np.hstack((y_train, y_data[sample_count:(total_count)]))
    x_test = np.vstack((x_test, x_data[(total_count + 1):(total_count + testingInst), :]))
    y_test = np.hstack((y_test, y_data[(total_count + 1):(total_count + testingInst)]))
  
  x_train = x_train[1:, :]
  x_test = x_test[1:, :]
  
  return x_train, y_train, x_test, y_test  

def storeData (xTrain, yTrain, xTest, yTest):
  #training data
  file = open("trainingData.txt", "w")
  rows = yTrain.shape[0]
  xTrain = createtranspose(xTrain)
  row_x, col_x = xTrain.shape
  writetofile(file,rows,xTrain,yTrain,row_x,col_x)
  # test data
  file = open("testingData.txt", "w")
  n = yTest.shape[0]
  xTest = createtranspose(xTest)
  row_x, col_x = xTest.shape
  writetofile(file,n,xTest,yTest,row_x,col_x)
  
  
#Creating training and testing data for centroid classifier
def storeCentroidData(x_train, y_train, x_test, y_test, trainingLen):
    #training data
    file = open("CentroidTrainingdata.txt", "w")
    for i in range(1, 41):
        file.write(str(int(i)))
        if (i < 40):
            file.write(',')
    file.write("\n")
    x_train = createtranspose(x_train)
    row_x, col_x = x_train.shape
    for i in range(0, row_x):
        for j in range (0, 40):
            classXCen = round((float(np.sum(x_train[i][j*trainingLen:(j+1)*trainingLen])/trainingLen)), 2)
            file.write(str(classXCen))
            if (j < 39):
                file.write(',')
        file.write('\n')
    file.close()

    #testing data
    file = open("CentroidTestingdata.txt", "w")
    rows = y_test.shape[0]
    for i in range(0, rows):
        file.write(str(int(y_test[i])))
        if (i < rows - 1):
            file.write(',')
    file.write("\n")
    x_test = createtranspose(x_test)
    row_x, col_x = x_test.shape
    for i in range(0, row_x):
        for j in range(0, col_x):
            file.write(str(int(x_test[i][j])))
            if (j < col_x - 1):
                file.write(',')
        file.write("\n")
    file.close()

# Calculating the Euclidean distance for KNN and Centroid classifier
def get_Edistance(x1, x2, length):
  e_distannce = 0
  for x in range(length):
      e_distannce += pow((x1[x] - x2[x]), 2)  # (x1 - x2)^2
  return math.sqrt(e_distannce)
# Finding the k nearest neighbors
def get_Kneighbors(trainingdataSet, testingInst, k):
	distances = []
	length = len(testingInst)-1
	for x in range(len(trainingdataSet)):
		dist = get_Edistance(testingInst, trainingdataSet[x], length)
		distances.append((trainingdataSet[x], dist))
	distances.sort(key=operator.itemgetter(1))   # to sort the distances from shortest to longest
	neighbors = []
	for x in range(k):
		neighbors.append(distances[x][0])
	return neighbors

# Finding the Nearest Neighbors
def get_Knneighbors(neighbors):

    classVotes = {}
    for x in range(len(neighbors)):
        response = neighbors[x][0]

        if response in classVotes:
            classVotes[response] += 1
        else:
            classVotes[response] = 1
    sortedVotes = sorted(classVotes.items(), key=operator.itemgetter(1), reverse=True)

    return sortedVotes[0][0]

# Evaluating the accuracy of the classifier
def get_Accuracyval(testdataSet, predictions):
    count_correct = 0
    for x in range(len(testdataSet)):
        if testdataSet[x][0] == predictions[x]:
            count_correct += 1
    accuracy=count_correct/float(len(testdataSet))
    percentaccuracy=accuracy*100.0        
    return percentaccuracy


  
def classify_crossval(classifier):
  fileName = 'ATNTFaceImages400.txt';
  class_ids = [x for x in range(1, 41, 1)]   # no. of classes
  fileName
  samples = 10            # there are 10 images for each person
  trainingInst = 8    # out of 10 images, 8 are used for training 
  testingInst = 2     # 2 for testing
  # for splitting image data into 2 sets: training and testing 
  x_train, y_train, x_test, y_test = pickDataClass(fileName, class_ids, samples, trainingInst, testingInst)
  
  xTrain = x_train
  yTrain = y_train
  xTest = x_test
  yTest = y_test  
  folds = [5]   # 5-fold cross validation
  arr = []
  c = []
  if (classifier == "KNN"):
      for i in folds:
          kf = KFold(n_splits=i, shuffle=True)
          sum_acc = 0
          
          for training_index, testing_index in kf.split(dataX):
              xTrain, xTest = dataX[training_index], dataX[testing_index]
              yTrain, yTest = dataY[training_index], dataY[testing_index]
              storeData(xTrain, yTrain, xTest, yTest)
              
              file1 = pd.read_csv("trainingData.txt", header=None)
              trainingData = file1.values
              trainingData = trainingData.transpose()
              
              file2 = pd.read_csv("testingData.txt", header=None)
              testingData = file2.values
              testingData = testingData.transpose()
              
              predictions=[]
              k = 5
              for x in range(len(testingData)):
                  neighbors = get_Kneighbors(trainingData, testingData[x], k)
                  nearestClass = get_Knneighbors(neighbors)
                  predictions.append(nearestClass)
              accuracy = get_Accuracyval(testingData, predictions)
              print("Accuracy using KNN and {:d}-fold cross validation: {:05.2f}%".format(i, accuracy))
              sum_acc = sum_acc + accuracy
          avg_acc = sum_acc / i
          print("Average Accuracy: {:05.2f}%".format(avg_acc));
          arr.append(avg_acc)
      c = c + [j for j in arr]

  elif (classifier == "SVM"):
      for i in folds:
          kf = KFold(n_splits=i, shuffle=True)
          sumacc = 0
          for training_index, testing_index in kf.split(dataX):
              x_train, x_test = dataX[training_index], dataX[testing_index]
              y_train, y_test = dataY[training_index], dataY[testing_index]
              svmclassifier = svm.LinearSVC()
              svmclassifier.fit(x_train, y_train)
              # calculating prediction
              predicted = svmclassifier.predict(x_test)
              
              actual = y_test
              accuracy = metrics.accuracy_score(actual, predicted) * 100
              # printing accuracy
              print("Accuracy using SVM and {:d}-fold cross validation: {:05.2f}%".format(i, accuracy))
              sumacc = sumacc + accuracy
          avg_acc = sumacc / i
          print("Average Accuracy: {:05.2f}%".format(avg_acc))
          arr.append(avg_acc)
      c = c + [j for j in arr]
      
  elif (classifier == "Linear Regression"):
      for i in folds:
          kf = KFold(n_splits=i, shuffle=True)
          sumacc = 0
          for training_index, testing_index in kf.split(dataX):
              x_train, x_test = dataX[training_index], dataX[testing_index]
              y_train, y_test = dataY[training_index], dataY[testing_index]
              rx_train, cx_train = x_train.transpose().shape
              rx_test, cx_test = x_test.transpose().shape

              Atrain = np.ones((1,cx_train ))
              Atest = np.ones((1,cx_test))
              Xtrain_padding = np.row_stack((x_train.transpose(),Atrain))
              Xtest_padding = np.row_stack((x_test.transpose(), Atest)) # computing the regression coefficients

              B_padding = np.dot(np.linalg.pinv(Xtrain_padding.T), y_train.T)

              ytest_padding = np.dot(B_padding.T,Xtest_padding)
              ytest_padding_argmax = np.argmax(ytest_padding,axis=0)+1
              err_test_padding = y_test - ytest_padding_argmax
              
              accuracy = (float((np.nonzero(err_test_padding)[0].size-1)/len(err_test_padding)))*100
              print("Accuracy using LR and {:d}-fold cross validation: {:05.2f}%".format(i, accuracy))
              sumacc = sumacc + accuracy
          avg_acc = sumacc / i
          print("Average Accuracy: {:05.2f}%".format(avg_acc))
          arr.append(avg_acc)
      c = c + [j for j in arr]
  elif (classifier == "Centroid"):
      for i in folds:
          kf = KFold(n_splits=i, shuffle=True)
          sumacc = 0
          for training_index, testing_index in kf.split(dataX):
              xTrain, xTest = dataX[training_index], dataX[testing_index]
              yTrain, yTest = dataY[training_index], dataY[testing_index]

              storeCentroidData(xTrain, yTrain, xTest, yTest, trainingInst)

              file1 = pd.read_csv("CentroidTrainingdata.txt", header=None)
              trainingData = file1.values
              trainingData = trainingData.transpose()
              
              file2 = pd.read_csv("CentroidTestingdata.txt", header=None)
              testingData = file2.values
              testingData = testingData.transpose()
              
              predictions=[]
              k = 5
              for x in range(len(testingData)):
                  neighbors = get_Kneighbors(trainingData, testingData[x], k)
                  nearestClass = get_Knneighbors(neighbors)
                  predictions.append(nearestClass)
              accuracy = get_Accuracyval(testingData, predictions)
              print("Accuracy using Centroid and {:d}-fold cross validation: {:05.2f}%".format(i, accuracy))
              sumacc = sumacc + accuracy
          avg_acc = sumacc / i
          print("Average Accuracy: {:05.2f}%".format(avg_acc))
          arr.append(avg_acc)
      c = c + [j for j in arr]     
  return c



y_knn = classify_crossval("KNN")
y_centroid = classify_crossval("Centroid")
y_svm = classify_crossval("SVM")
y_lr = classify_crossval("Linear Regression")




# Plotting performance

classifiers = np.array(['KNN','SVM', 'Lin Reg.','Centroid'])
y_pos = np.arange(len(classifiers))
performance = np.array([y_knn[0],y_svm[0], y_lr[0], y_centroid[0]])
plotter.rcdefaults()
plotter.barh(y_pos, performance, align='center', color='green')
plotter.yticks(y_pos, classifiers)
plotter.xlabel('Prediction - Accuracy')
plotter.title('Classifier Performance : ATNT FaceData')
plotter.savefig('ClassifierPerformance.png', bbox_inches='tight') 
plotter.show()
