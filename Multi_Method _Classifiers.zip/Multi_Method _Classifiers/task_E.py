"""
Name:Omkar Sahasrabudhe
Name: Prem Patel
ID :1001668155
Id : 1001661919
"""
import numpy as np
import pandas as pd



def writetofile(file,rows,xT,yT,row_x,col_x):
    for i in range(0, rows):
        file.write(str(int(yT[i])))
        if (i < rows - 1):
            file.write(',')
    file.write("\n")   
    for i in range(0, row_x):
        for j in range(0, col_x):
            file.write(str(int(xT[i][j])))
            if (j < col_x - 1):
                file.write(',')
        file.write("\n")
    file.close()

def pickData(fileName, Nclass, trainingInst, testingInst):
  data = pd.read_csv(fileName, header = None).values
  x_data = np.transpose(data[1:, :])
  y_data = np.transpose(data[0, :])
  
  Nx = data.shape[0] - 1
  
  y_train, y_test = [], []
  x_train = np.zeros((1, Nx))
  x_test = np.zeros((1, Nx))
  
  for cid in Nclass:
    i = cid - 1
    samples_count=samples* i
    total_count=(samples_count)+ trainingInst
    x_train = np.vstack((x_train, x_data[(samples_count):(total_count), :]))
    y_train = np.hstack((y_train, y_data[(samples_count):(total_count)]))
    x_test = np.vstack((x_test, x_data[(total_count + 1):(total_count + testingInst), :]))
    y_test = np.hstack((y_test, y_data[(total_count + 1):(total_count + testingInst)]))
  
  x_train = x_train[1:, :]
  x_test = x_test[1:, :]
  
  return x_train, y_train, x_test, y_test 

def storeData (xTrain, yTrain, xTest, yTest):
  file = open("trainingData.txt", "w")
  rows = yTrain.shape[0]
  xTrain = np.transpose(xTrain)
  row_x, col_x = xTrain.shape
  writetofile(file,rows,xTrain,yTrain,row_x,col_x)
  
  # test data
  file = open("testingData.txt", "w")
  n = yTest.shape[0]
  xTest = np.transpose(xTest)
  row_x, col_x = xTest.shape
  writetofile(file,n,xTest,yTest,row_x,col_x)
  



def letter_2_digit_convertlist(word):
     name_number = {'a':1, 'b':2, 'c':3, 'd':4,'e':5, 'f':6, 'g':7, 'h':8,'i':9, 'j':10, 'k':11, 'l':12,'m':13, 'n':14, 'o':15, 'p':16,'q':17, 'r':18, 's':19, 't':20,'u':21, 'v':22, 'w':23,'x':24,'y':25, 'z':26}
     classid=[];
     #print(word)            

     for i in word:     
        classid.append(name_number[i])
     #print(classid)
     return classid 


#'ATNTFaceImages400.txt';
samples = 0
filename="HandWrittenLetters.txt"
if(filename == "ATNTFaceImages400.txt"):
    samples = 10
elif(filename == 'HandWrittenLetters.txt'):
    samples = 39

Nclass = [3, 10, 22]
trainingInsts = 30
testingInsts = 9

train_X, train_Y, test_X, test_Y = pickData(filename, Nclass, trainingInsts, testingInsts)
print("training_X : ", train_X.shape)
print("training_Y : ", train_Y.shape)
print("test_X : ", test_X.shape)
print("test_Y : ", test_Y.shape)
storeData(train_X, train_Y, test_X, test_Y)
indexes = letter_2_digit_convertlist('test')
print(indexes)
